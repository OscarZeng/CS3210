Name:Zeng Hao; Student Number: A0177355W
How to compile run my program: type "gcc -pthread -o ex7 ex7-prod-con-threads.c"and "gcc -pthread -o ex8 ex8-prod-con-processes.c" 
to compile the code for exercise 8 and exercise 9 respectively. Afterwards, run the program using command "./ex7" and "./ex8".

Exercise 9:
The time taken for the processes case to complete the program is more than the time taken for threads case to complete the program.